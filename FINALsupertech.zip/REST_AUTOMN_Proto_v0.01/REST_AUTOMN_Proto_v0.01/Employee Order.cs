﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace REST_AUTOMN_Proto_v0._01
{
    public partial class Employee_Order : Form
    {
        string menu_item;
        StreamWriter mywriter;
        string table_number;

        public Employee_Order(string menu_item, StreamWriter writer, string table)
        {
            InitializeComponent();
            this.menu_item = menu_item;
            this.mywriter = writer;
            this.table_number = table;

            mywriter.WriteLine("ORDER FOR: Table " + table_number);
            header.Text = "Item to add to order: " + menu_item;
        }

        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            // send to csv file
            MessageBox.Show(menu_item + " submitted to order");
            mywriter.WriteLine(menu_item);
            if (directions.Text != "")
            {
                mywriter.WriteLine("    " + directions.Text);
            }

            this.Close();
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Item Canceled");
            this.Close();
        }
    }
}
