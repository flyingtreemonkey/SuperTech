﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REST_AUTOMN_Proto_v0._01
{
    public class Menu_Item
    {
        public string menu_item_name { get; set; }
        string[] inventory_items = new string[8] { "", "", "", "", "", "", "", "" };
        int inventory_count = 0;

        public Menu_Item(string m_item_name)
        {
            menu_item_name = m_item_name;
        }



        public int add_inventory_item(string inventory_item)
        {
            if (inventory_count != 7)
            {
                inventory_items[inventory_count] = inventory_item;
                inventory_count += 1;

                return 1;
            }

            return 0;
        }
    }
}
