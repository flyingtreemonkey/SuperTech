﻿CREATE TABLE [dbo].[passTable]
(
	[Password] VARCHAR(50) NOT NULL PRIMARY KEY, 
    CONSTRAINT [PK_passwordsTable] PRIMARY KEY ([Password])
)
