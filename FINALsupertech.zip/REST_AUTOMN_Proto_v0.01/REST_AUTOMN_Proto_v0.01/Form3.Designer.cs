﻿namespace REST_AUTOMN_Proto_v0._01
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Menu_Item_Name = new System.Windows.Forms.TextBox();
            this.items = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.used_items = new System.Windows.Forms.DataGridView();
            this.Items_associated = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.items)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.used_items)).BeginInit();
            this.SuspendLayout();
            // 
            // Menu_Item_Name
            // 
            this.Menu_Item_Name.Location = new System.Drawing.Point(190, 27);
            this.Menu_Item_Name.Name = "Menu_Item_Name";
            this.Menu_Item_Name.ReadOnly = true;
            this.Menu_Item_Name.Size = new System.Drawing.Size(436, 20);
            this.Menu_Item_Name.TabIndex = 0;
            // 
            // items
            // 
            this.items.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.items.Location = new System.Drawing.Point(172, 125);
            this.items.Name = "items";
            this.items.Size = new System.Drawing.Size(227, 160);
            this.items.TabIndex = 1;
            this.items.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellContentClick);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(122, 99);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(94, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "Items in Inventory";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(172, 316);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(483, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.TextChanged += new System.EventHandler(this.TextBox2_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(122, 291);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(80, 20);
            this.textBox3.TabIndex = 0;
            this.textBox3.Text = "Add Item";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(692, 165);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 47);
            this.button1.TabIndex = 4;
            this.button1.Text = "Select Ingredients from Inventory";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(692, 305);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(86, 51);
            this.button2.TabIndex = 5;
            this.button2.Text = "Select Ingredient Manually";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // used_items
            // 
            this.used_items.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.used_items.Location = new System.Drawing.Point(433, 125);
            this.used_items.Name = "used_items";
            this.used_items.Size = new System.Drawing.Size(221, 159);
            this.used_items.TabIndex = 6;
            // 
            // Items_associated
            // 
            this.Items_associated.Location = new System.Drawing.Point(558, 99);
            this.Items_associated.Name = "Items_associated";
            this.Items_associated.ReadOnly = true;
            this.Items_associated.Size = new System.Drawing.Size(107, 20);
            this.Items_associated.TabIndex = 7;
            this.Items_associated.Text = "Items";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Items_associated);
            this.Controls.Add(this.used_items);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.items);
            this.Controls.Add(this.Menu_Item_Name);
            this.Name = "Form3";
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.items)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.used_items)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Menu_Item_Name;
        private System.Windows.Forms.DataGridView items;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView used_items;
        private System.Windows.Forms.TextBox Items_associated;
    }
}