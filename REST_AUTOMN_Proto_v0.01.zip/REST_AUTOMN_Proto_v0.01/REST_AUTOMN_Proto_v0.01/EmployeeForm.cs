﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;


// EMPLOYEE COMPONENT
// this form is the window that the employee sees when logging in
// the current menus of the day are to be populated from the database based on the day
// from here the employee can select the menu, menu-items to prepare and execute a order
// statistics on employee activity is to be stored and exported naturally
// NOT COMPLETED dependent upon code of the manager/Inventory Database compenet to work in the REST_AUTMN_OVRVW.cs file
namespace REST_AUTOMN_Proto_v0._01
{
    public partial class EmployeeForm : Form
    {
        public EmployeeForm()
        {
            InitializeComponent();
            Menus.Columns.Add("Menus", "Menu's Today");
        }

        // string for connecting to database
        private string buildConnectionString()
        {

            return "Host = localhost; Username = postgres; Database = supertech; password =sophie";
        }


        private void obtain_menus(string sqlstr, Action<NpgsqlDataReader> function)
        {
            using (var con = new NpgsqlConnection(buildConnectionString()))
            {
                con.Open();


                using (var cmd = new NpgsqlCommand())
                {

                    cmd.Connection = con;
                    cmd.CommandText = sqlstr;

                    try
                    {
                        var reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            function(reader);
                        }
                    }
                    catch (NpgsqlException ex)
                    {
                        Console.WriteLine(ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
        }

        private void post_menus(NpgsqlDataReader reader)
        {


        }
    }
}
