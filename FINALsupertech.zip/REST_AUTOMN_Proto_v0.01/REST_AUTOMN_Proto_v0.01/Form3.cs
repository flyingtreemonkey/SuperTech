﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

// THIS FORM will pefrom the invetnory database component
// It will list the current items in the database as a function of adding the ingredients
// to a menu-item's profile
// Managers can manually insert into the database new items by clicking the corresponding button
// otherwise the inventory item is just added to the menu item
// NOT FULLY IMPLEMENTED
namespace REST_AUTOMN_Proto_v0._01
{
    // inventory items form
    public partial class Form3 : Form
    {
        Menu_Item this_menu_item;

        public Form3(string to_insert)
        {
            this_menu_item = new Menu_Item(to_insert);
            InitializeComponent();
            Items_associated.Text = "Items Used in Making " + to_insert;
            Menu_Item_Name.Text = this_menu_item.menu_item_name;
            items.Columns.Add("ingredient", "Ingredient");
            items.Columns.Add("count", "Count");

            used_items.Columns.Add("ingredient", "Ingredient");

            // obtain existing inventory
            display_inventory();

            // obtain items used in making this menu item
            display_used();
        }

        private void display_inventory()
        {
            items.Rows.Clear();
            string sql_str1 = "SELECT * FROM Inventory_Items;";
            obtain_inventory(sql_str1);
        }

        private void display_used()
        {
            used_items.Rows.Clear();
            string sql_str2 = "SELECT * FROM Menu_Items WHERE menu_item_name = '" + this_menu_item.menu_item_name + "';";
            obtain_existing(sql_str2);
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private string buildConnectionString()
        {

            return "Host = localhost; Username = postgres; Database = supertech; password =sophie";
        }

        private void obtain_existing(string sqlstr)
        {
            using (var con = new NpgsqlConnection(buildConnectionString()))
            {
                con.Open();


                using (var cmd = new NpgsqlCommand())
                {

                    cmd.Connection = con;
                    cmd.CommandText = sqlstr;

                    try
                    {
                        var reader = cmd.ExecuteReader();
                        while(reader.Read())
                        {
                            for (int i = 1; i < reader.FieldCount - 1; i++)
                            {
                                try
                                {
                                    string item_used = reader.GetString(i).Trim(' ');
                                    used_items.Rows.Add(item_used);
                                }
                                catch
                                {
                                    break;
                                }
                            }
                        }
                    }
                    catch
                    {


                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
        }

        // runs a sql query for adding existing inventory items to the menu_item
        private void obtain_inventory(string sqlstr)
        {
            using (var con = new NpgsqlConnection(buildConnectionString()))
            {
                con.Open();


                using (var cmd = new NpgsqlCommand())
                {

                    cmd.Connection = con;
                    cmd.CommandText = sqlstr;

                    try
                    {
                        var reader = cmd.ExecuteReader();
                        while(reader.Read())
                        {
                            string inv_name = reader.GetString(0).Trim(' ');
                            int inv_count = reader.GetInt32(1);
                            items.Rows.Add(inv_name, inv_count);
                        }
                    }
                    catch
                    {

                        
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
        }

        private int single_query(string sqlstr)
        {
            int answer = 0;

            using (var con = new NpgsqlConnection(buildConnectionString()))
            {
                con.Open();


                using (var cmd = new NpgsqlCommand())
                {

                    cmd.Connection = con;
                    cmd.CommandText = sqlstr;

                    try
                    {
                        var reader = cmd.ExecuteReader();

                        if (reader.HasRows)
                        {

                            answer = 1;
                        }
                    }
                    catch
                    {

                        answer = 0;
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }

            return answer;
        }
        

        // This button is meant for manually entering a string for the ingredient used in the menu_item
        private void Button2_Click(object sender, EventArgs e)
        {
            // first add the ingredient to the inventory since the menu item references them
            string sql_str1 = "INSERT INTO Inventory_Items (inventory_item_name) VALUES ('" + textBox2.Text.Trim(' ') + "');";

            single_query(sql_str1);

            display_inventory();

            string m_number = (used_items.Rows.Count).ToString();

            // update the menu_item based on the number of items listed in the used_item box
            string sql_str2 = "UPDATE Menu_Items SET i_" + m_number + " = '" + textBox2.Text.Trim(' ') + "' WHERE menu_item_name = '" + this_menu_item.menu_item_name + "';";

            single_query(sql_str2);

            display_used();
        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (items.SelectedCells.Count > 0)
            {
                string m_number = (used_items.Rows.Count).ToString();

                // update the menu_item based on the number of items listed in the used_item box
                string sql_str2 = "UPDATE Menu_Items SET i_" + m_number + " = '" + items.SelectedCells[0].Value + "' WHERE menu_item_name = '" + this_menu_item.menu_item_name + "';";

                single_query(sql_str2);

                display_used();
            }
        }
    }
}
