﻿/*
 * SuperTech.INC Restaurant Automation Application
 * Prototype v0.01
 * Last Edited - 3/22/20 by Zach Gherman
 * 
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace REST_AUTOMN_Proto_v0._01
{
    public partial class REST_AUTMN_OVRVW : Form
    {
        public REST_AUTMN_OVRVW()
        {
            InitializeComponent();
        }

        public class Employee
        {
            // Constructor that takes no arguments:
            public Employee()
            {
                Name = "unknown";
            }

            // Constructor that takes one argument:
            public Employee(int id)
            {
                EmployeeID = id;
            }

            // Auto-implemented readonly property:
            public string Name { get; }
            private int EmployeeID { get; }


            //Makeorder funct
            // takes as input, details about the order.. Can be linked list if we want.
            // public so all employees (managers included) can use it.
            public void MakeOrder()
            {
                // TODO: FINISH THIS!
                return;
            }

            // Method that overrides the base class (System.Object) implementation.
            public override string ToString()
            {
                return Name;
            }
        }

        public class Manager : Employee
        {
            public Manager()
            {
                // Uses Employee's methods to update values from inheritance.
            }

            private void updateMenu()
            {
                // TODO: NEED TO IMPLEMENT THIS!
                return;
            }
            private void updateInventory()
            {
                // TODO: NEED TO IMPLEMENT THIS
                return;
            }
        }

        //public static string InputBox(string Prompt, string Title = "", string DefaultResponse = "", int XPos = -1, int YPos = -1);


        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Exit without saving", "Are you sure you want to exit without saving?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                // Environment.Exit(0) sends the exit code (0) and closes all open winforms.
                // This is useful as we only hid the log-in screen, we didn't close it.
                Environment.Exit(0);

                /*	
                 *	Resource: http://net-informations.com/faq/general/close-exit.htm
                 *	System.Windows.Forms.Application.Exit() informs all message pumps that they must terminate, and then closes all application windows after the messages have been processed,
                 *	so it giving your forms the possibility to execute their cleanup code. 
                 *	In a multithreading program, Application.Exit() will not terminate all your threads instead you are only exiting from the current thread context, while leaving any started 
                 *	foreground threads running. In this case you should take measures to kill your other threads, either in the main function or when in the OnClose event of your main form.
                 *	*/
            }

        }


        // This is the button to add buttons!
        private void button2_Click(object sender, EventArgs e)
        {
            // TODO: Create a database that stores the information of the dynamically created buttons.
            // Resources: to accomplish this task,
            // https://stackoverflow.com/questions/34828445/how-can-i-save-button-which-was-dynamically-created
            // 
            Button btn = addButton();
            // used flowLayoutPanel so we don't have to worry about creating buttons that fit within the page...
            // the layout panel does it automatically!
            flowLayoutPanel1.Controls.Add(btn);

        }

        // Resource:
        // https://www.csharp-examples.net/inputbox/
        public static DialogResult InputBox(string title, string promptText, ref string value)
        {
            Form form = new Form();
            Label label = new Label();
            TextBox textBox = new TextBox();
            Button buttonOk = new Button();
            Button buttonCancel = new Button();

            form.Text = title;
            label.Text = promptText;
            textBox.Text = value;

            buttonOk.Text = "OK";
            buttonCancel.Text = "Cancel";
            buttonOk.DialogResult = DialogResult.OK;
            buttonCancel.DialogResult = DialogResult.Cancel;

            label.SetBounds(9, 20, 372, 13);
            textBox.SetBounds(12, 36, 372, 20);
            buttonOk.SetBounds(228, 72, 75, 23);
            buttonCancel.SetBounds(309, 72, 75, 23);

            label.AutoSize = true;
            textBox.Anchor = textBox.Anchor | AnchorStyles.Right;
            buttonOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;

            form.ClientSize = new Size(396, 107);
            form.Controls.AddRange(new Control[] { label, textBox, buttonOk, buttonCancel });
            form.ClientSize = new Size(Math.Max(300, label.Right + 10), form.ClientSize.Height);
            form.FormBorderStyle = FormBorderStyle.FixedDialog;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.MinimizeBox = false;
            form.MaximizeBox = false;
            form.AcceptButton = buttonOk;
            form.CancelButton = buttonCancel;

            DialogResult dialogResult = form.ShowDialog();
            value = textBox.Text;
            return dialogResult;
        }

        Button addButton()
        {
            string menu = "New Menu Name";

            Button btn = new Button();
            if (InputBox("New Menu Name", "Enter New Menu Name:", ref menu) == DialogResult.OK)
            {
                btn.Name = menu;
            }
            btn.Text = menu;
            btn.Width = 120;
            btn.Height = 80;
            btn.TextAlign = ContentAlignment.MiddleCenter;
            btn.Margin = new Padding(5);

            btn.Click += new EventHandler(DynamicButton_Click);

            return btn;
        }

        // This allows us to click the buttons we create!
        private void DynamicButton_Click(object sender, EventArgs e)
        {
            Form form = new Form();
            form.Location = new Point(20, 50);
            form.Width = 820;
            form.SuspendLayout();
            int usedHeight = 500;
            string menuName = "Menu";
            //form.Name = menuName;
            form.Text = menuName;
            

            //if (InputBox("New Menu ", "New Menu Name:", ref menuName) == DialogResult.OK);
            //    form.Name = menuName;
                // TODO: ADD FLOWPANELLAYOUT AND EXIT BUTTON AND ADD FOOD ITEM BUTTON.

            // example on how to add labels, can be modified to add buttons, etc.
            //Label label = new Label();
            //label.Text = "this is a test";
            //label.Top = 10; label.Left = 5;
            //form.Controls.Add(label);

            //form.Controls.Add(button1); // these reference the previous forms buttons. Need to make them reference the new form.
            Button exitBtn = new Button();
            exitBtn.Height = button1.Height;
            exitBtn.Width = button1.Width;
            exitBtn.Top = button1.Top;
            exitBtn.Left = button1.Left;
            exitBtn.Click += (_,args)=> { form.Close(); }; // IT WORKS!
            exitBtn.Text = "Exit Menu";
            form.Controls.Add(exitBtn);
            // now do the same you did for the exit button for button2.

            //form.Controls.Add(button2);
            FlowLayoutPanel newMenu = new FlowLayoutPanel();
            newMenu.Left = 5; newMenu.Top = 10;
            newMenu.Width = 670; newMenu.Height = usedHeight-75;
            //newMenu.BackColor = Color.Green; // see what the size of the flow panel looks like
            newMenu.Name = "newMenuFlowLayoutPanel";
            form.Controls.Add(newMenu);

            // example of how to add a text box.
            //TextBox textBox = new TextBox();
            //textBox.Text = "this is a test text.";
            //textBox.Top = usedHeight - 400; textBox.Left = 80;
            //textBox.Width = 115;
            //textBox.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
            //form.Controls.Add(textBox);


            Button addItemBtn = new Button();
            addItemBtn.Height = button2.Height; addItemBtn.Width = button2.Width; addItemBtn.Top = button2.Top; addItemBtn.Left = button2.Left;
            addItemBtn.Text = "Add New Food Item";
            addItemBtn.Click += (_, args) => {
                Button btn = new Button();
                string foodName = "";
                if (InputBox("New Food Name", "Enter New Food Item Name:", ref foodName) == DialogResult.OK)
                {
                    btn.Name = foodName;
                }
                btn.Text = foodName;
                btn.Width = 120;
                btn.Height = 80;
                btn.TextAlign = ContentAlignment.MiddleCenter;
                btn.Margin = new Padding(5);

                // provide a click function for the buttons created dynamically here.
                // these buttons should call the classes "add to order" function and act appropriately.
                btn.Click += Btn_Click;

                newMenu.Controls.Add(btn);
            };
            form.Controls.Add(addItemBtn);

            //usedHeight += textBox.Height + 5;


            form.ResumeLayout();
            form.Height = usedHeight + 10;
            form.Show();
            
            //MessageBox.Show("You clicked a Dynamically Created button, YAY!");
        }

        private void Btn_Click(object sender, EventArgs e)
        {
            //TODO: THIS NEEDS TO HANDLE THE INVENTORY AND ADD THE REQUESTED ITEM TO THE ORDER
            MessageBox.Show("You clicked a thing!");
        }


        // exit button for internal menus. Needs to be adjusted to close the proper window.
        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void addEmployeeBttn_Click(object sender, EventArgs e)
        {
            
            //MessageBox.Show("This does nothing yet.");
        }

    }
}
