﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// THIS FORM will pefrom the invetnory database component
// It will list the current items in the database as a function of adding the ingredients
// to a menu-item's profile
// Managers can manually insert into the database new items by clicking the corresponding button
// otherwise the inventory item is just added to the menu item
// NOT FULLY IMPLEMENTED
namespace REST_AUTOMN_Proto_v0._01
{
    // inventory items form
    public partial class Form3 : Form
    {
        Menu_Item this_menu_item;

        public Form3(string to_insert)
        {
            this_menu_item = new Menu_Item(to_insert);
            InitializeComponent();
            Menu_Item_Name.Text = this_menu_item.menu_item_name;
            items.Columns.Add("ingredient", "Ingredient");
            items.Rows.Add("testing");

        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
