﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;


// This FORM implements the addition of new employees into the database
// Addition of managers is run through the company for security reasons 
// aka MANUALLY entered into the DB not through teh GUI
namespace REST_AUTOMN_Proto_v0._01
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private string buildConnectionString()
        {

            return "Host = localhost; Username = postgres; Database = supertech; password =sophie";
        }


        private void employees_insert(string sqlstr)
        {
            using (var con = new NpgsqlConnection(buildConnectionString()))
            {
                con.Open();


                using (var cmd = new NpgsqlCommand())
                {

                    cmd.Connection = con;
                    cmd.CommandText = sqlstr;

                    try
                    {
                        var reader = cmd.ExecuteReader();
                    }
                    catch (NpgsqlException ex)
                    {
                        Console.WriteLine(ex.Message.ToString());
                        //System.Windows.MessageBox.Show("SQL Error - " + ex.Message.ToString());
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                string sql_str = "INSERT INTO Employees (employee_id, employee_password) VALUES ('" + textBox1.Text.Trim(' ') + "', '" + textBox2.Text.Trim(' ') + "');";
                employees_insert(sql_str);
                Console.WriteLine("Insert Completed, closing window");

                this.Close();
            }
        

        }
    }
}
