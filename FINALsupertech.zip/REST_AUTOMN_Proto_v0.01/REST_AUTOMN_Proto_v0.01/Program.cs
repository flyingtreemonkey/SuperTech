﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace REST_AUTOMN_Proto_v0._01
{
    static class Program
    {

        // FORGIVE THE NAMING OF CLASSES
        // it is very difficult in windows forms to rename classes and objects without everythihng crashing
        // please look to the comments at the top of the forms and classes for direction
        // MAIN program, this creates the initial login form
        [STAThread]
        static void Main()
        {
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
