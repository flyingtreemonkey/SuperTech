﻿namespace REST_AUTOMN_Proto_v0._01
{
    partial class Employee_Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.header = new System.Windows.Forms.TextBox();
            this.directions = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CancelButton = new System.Windows.Forms.Button();
            this.Submit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // header
            // 
            this.header.Location = new System.Drawing.Point(227, 42);
            this.header.Name = "header";
            this.header.ReadOnly = true;
            this.header.Size = new System.Drawing.Size(315, 20);
            this.header.TabIndex = 0;
            // 
            // directions
            // 
            this.directions.Location = new System.Drawing.Point(227, 106);
            this.directions.Name = "directions";
            this.directions.Size = new System.Drawing.Size(315, 141);
            this.directions.TabIndex = 1;
            this.directions.Text = "";
            this.directions.TextChanged += new System.EventHandler(this.RichTextBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(199, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Notes for Cooks";
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(705, 392);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(83, 49);
            this.CancelButton.TabIndex = 3;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // Submit
            // 
            this.Submit.Location = new System.Drawing.Point(705, 160);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(82, 53);
            this.Submit.TabIndex = 4;
            this.Submit.Text = "Submit Item to Order";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // Employee_Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.directions);
            this.Controls.Add(this.header);
            this.Name = "Employee_Order";
            this.Text = "Employee_Order";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox header;
        private System.Windows.Forms.RichTextBox directions;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Button Submit;
    }
}